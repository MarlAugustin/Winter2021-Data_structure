
public class pratique {

	public static void main(String[] args) {
		int base=2, valeurMax=100;
		int r�sultat = 0, exposant = 0;
		do {
			System.out.println(r�sultat=(int) Math.pow(base, (exposant)));
			System.out.println(exposant);
			exposant++;
		}while (r�sultat <= valeurMax);
		exposant=exposant-1;
	}

}
