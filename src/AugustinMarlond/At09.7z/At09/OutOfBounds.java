package AugustinMarlond.At09;

import java.util.Scanner;

public class OutOfBounds extends Exception {
	Scanner clavier = new Scanner(System.in);

	public OutOfBounds() {
		super();
	}

	public OutOfBounds(String message) {
			super(message);
			}
			}
